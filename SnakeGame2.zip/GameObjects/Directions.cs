﻿namespace SnakeGame2.GameObjects
{
    public enum Direction
    {
        Right,
        Left,
        Down,
        Up,
    }
}
